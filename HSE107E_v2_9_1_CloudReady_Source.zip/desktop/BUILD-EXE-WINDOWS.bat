﻿@echo off
chcp 65001 >nul
title HSE 107E - Build Installer and Portable
cd /d "%~dp0"
echo ================================================
echo   HSE 107E - Windows Installer + Portable EXE
echo ================================================
where node >nul 2>nul
if errorlevel 1 (
  echo ERROR: Node.js LTS is not installed.
  pause
  exit /b 1
)
echo.
echo Installing build dependencies...
call npm install
if errorlevel 1 (
  echo ERROR: npm install failed.
  pause
  exit /b 1
)
echo.
echo Building NSIS installer and portable EXE...
call npm run dist
if errorlevel 1 (
  echo ERROR: Build failed. Review messages above.
  pause
  exit /b 1
)
echo.
echo SUCCESS. Check the dist folder for:
echo - HSE 107E Setup installer
echo - HSE107E-Portable.exe
pause
