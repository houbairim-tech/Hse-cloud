/* HSE107E Cloud authentication + sync (Cloudflare Worker/D1) */
(() => {
  'use strict';
  const API = 'https://hse107e-api.hse107e-cloud-api.workers.dev';
  const TOKEN_KEY = 'hse107e_cloud_token';
  const USER_KEY = 'hse107e_cloud_user';
  const BASELINE_KEY = 'hse107e_cloud_baseline';
  const LOCAL_USER_KEY = 'hse107e_v2_user';
  const LOCAL_USERS_KEY = 'hse107e_v2_users';
  const SKIP = /^(hse107e_cloud_|hse107e_v2_(user|users)$|__|drive|google)/i;
  const ROLE_PERMS = {
    admin:['*'],
    manager:['dashboard','actions','production','gemba','contact','autorisations','epc','cr','ptw','cons','reports','export'],
    supervisor:['dashboard','actions','production','gemba','contact','autorisations','epc','cr','ptw','cons','reports','export'],
    viewer:['dashboard','reports']
  };
  const safeParse = (s, fallback=null) => { try { return JSON.parse(s); } catch { return fallback; } };
  const token = () => localStorage.getItem(TOKEN_KEY) || '';
  const user = () => safeParse(localStorage.getItem(USER_KEY), null);
  const saveUser = u => localStorage.setItem(USER_KEY, JSON.stringify(u || null));
  const authHeaders = () => token() ? {Authorization:'Bearer '+token()} : {};
  const request = async (path, opts={}) => {
    const response = await fetch(API+path, {
      ...opts,
      headers:{'Content-Type':'application/json', ...(opts.headers||{})}
    });
    const data = await response.json().catch(()=>({}));
    if (!response.ok) throw new Error(data.error || `Erreur serveur (${response.status})`);
    return data;
  };
  function cacheLocalIdentity(u) {
    const role = ['admin','manager','supervisor','viewer'].includes(u.role) ? u.role : 'viewer';
    const name = u.displayName || u.display_name || u.email || 'Utilisateur';
    const cached = {id:u.id, u:u.email, name, r:role, active:true, perms:ROLE_PERMS[role]};
    localStorage.setItem(LOCAL_USERS_KEY, JSON.stringify([cached]));
    localStorage.setItem(LOCAL_USER_KEY, JSON.stringify({u:u.email,r:role,at:new Date().toISOString()}));
    return cached;
  }
  async function login(email, password) {
    const d = await request('/auth/login',{method:'POST',body:JSON.stringify({email,password})});
    localStorage.setItem(TOKEN_KEY,d.token);
    saveUser(d.user);
    cacheLocalIdentity(d.user);
    return d.user;
  }
  async function bootstrap(email,password,displayName,code) {
    const d = await request('/auth/bootstrap',{
      method:'POST',
      headers:{'X-Bootstrap-Code':code},
      body:JSON.stringify({email,password,displayName})
    });
    localStorage.setItem(TOKEN_KEY,d.token);
    saveUser(d.user);
    cacheLocalIdentity(d.user);
    return d.user;
  }
  async function restore() {
    if (!token()) {
      localStorage.removeItem(LOCAL_USER_KEY);
      return null;
    }
    try {
      const d = await request('/auth/me',{headers:authHeaders()});
      const normalized={...d.user,displayName:d.user.displayName||d.user.display_name||d.user.email};
      saveUser(normalized);
      cacheLocalIdentity(normalized);
      return d.user;
    } catch (e) {
      localStorage.removeItem(TOKEN_KEY);
      saveUser(null);
      localStorage.removeItem(LOCAL_USER_KEY);
      return null;
    }
  }
  async function logout() {
    try { if(token()) await request('/auth/logout',{method:'POST',headers:authHeaders()}); } catch {}
    localStorage.removeItem(TOKEN_KEY);
    saveUser(null);
    localStorage.removeItem(LOCAL_USER_KEY);
    localStorage.removeItem(LOCAL_USERS_KEY);
  }
  async function createUser(payload) {
    if (!token()) throw new Error('Veuillez vous connecter.');
    return request('/admin/users',{method:'POST',headers:authHeaders(),body:JSON.stringify(payload)});
  }
  function collect() {
    const out={};
    for(let i=0;i<localStorage.length;i++) {
      const key=localStorage.key(i);
      if(!key || SKIP.test(key)) continue;
      const value=localStorage.getItem(key);
      if(value==null || value.length>900000) continue;
      out[key]=safeParse(value,value);
    }
    return out;
  }
  const stable = value => {
    if(value===null || typeof value!=='object') return JSON.stringify(value);
    if(Array.isArray(value)) return '['+value.map(stable).join(',')+']';
    return '{'+Object.keys(value).sort().map(k=>JSON.stringify(k)+':'+stable(value[k])).join(',')+'}';
  };
  const baseline = () => safeParse(localStorage.getItem(BASELINE_KEY),{});
  const saveBaseline = b => localStorage.setItem(BASELINE_KEY,JSON.stringify(b));
  async function push() {
    if(!token()) throw new Error('Connexion Cloud requise.');
    const local=collect(), keys=Object.keys(local);
    const response=await request('/records?module=app',{headers:authHeaders()});
    const remote=new Map((response.records||[]).map(r=>[r.record_key,r]));
    const base=baseline();
    let uploaded=0, downloaded=0, unchanged=0, conflicts=[];
    for(const key of keys) {
      const r=remote.get(key), localValue=local[key];
      const remoteValue=r ? safeParse(r.payload,r.payload) : undefined;
      const prev=base[key];
      if(r && stable(remoteValue)===stable(localValue)) {
        base[key]={version:Number(r.version),payload:localValue}; unchanged++; continue;
      }
      if(r && !prev) { conflicts.push(key); continue; }
      if(r && prev && Number(r.version)!==Number(prev.version) &&
         stable(remoteValue)!==stable(prev.payload) &&
         stable(localValue)!==stable(prev.payload)) {
        conflicts.push(key); continue;
      }
      if(r && prev && stable(localValue)===stable(prev.payload) &&
         stable(remoteValue)!==stable(prev.payload)) {
        localStorage.setItem(key,typeof r.payload==='string'?r.payload:JSON.stringify(r.payload));
        base[key]={version:Number(r.version),payload:remoteValue}; downloaded++; continue;
      }
      const saved=await request('/records',{
        method:'POST',headers:authHeaders(),
        body:JSON.stringify({module:'app',key,payload:localValue,baseVersion:Number(r?.version||0)})
      });
      base[key]={version:Number(saved.record.version),payload:localValue}; uploaded++;
    }
    saveBaseline(base);
    return {uploaded,downloaded,unchanged,conflicts};
  }
  async function pull() {
    if(!token()) throw new Error('Connexion Cloud requise.');
    const d=await request('/records?module=app',{headers:authHeaders()});
    const b=baseline(); let count=0;
    for(const r of (d.records||[])) {
      const value=safeParse(r.payload,r.payload);
      if(SKIP.test(r.record_key)) continue;
      localStorage.setItem(r.record_key,typeof r.payload==='string'?r.payload:JSON.stringify(r.payload));
      b[r.record_key]={version:Number(r.version),payload:value}; count++;
    }
    saveBaseline(b);
    if(count) location.reload();
    return count;
  }
  const esc = x => String(x??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
  function addCloudButton() {
    if(document.getElementById('hse107eCloudBtn')) return;
    const b=document.createElement('button');
    b.id='hse107eCloudBtn';
    b.type='button';
    b.textContent=user()?'☁️ Cloud':'☁️ Cloud';
    b.style.cssText='position:fixed;right:14px;bottom:14px;z-index:100001;border:0;border-radius:999px;padding:12px 17px;background:#0b6585;color:white;font-weight:800;box-shadow:0 6px 22px #0004;cursor:pointer';
    b.onclick=openCloudPanel;
    document.body.appendChild(b);
  }
  function openCloudPanel() {
    let m=document.getElementById('hse107eCloudModal');
    if(!m) {
      m=document.createElement('div'); m.id='hse107eCloudModal';
      m.style.cssText='position:fixed;inset:0;z-index:100002;display:flex;align-items:center;justify-content:center;padding:16px;background:#07182ddd;font-family:Arial,sans-serif';
      m.innerHTML='<section style="width:min(430px,100%);background:#fff;border-radius:18px;padding:22px;box-shadow:0 20px 70px #0007"><h2 style="margin:0 0 6px;color:#10243a">☁️ HSE 107E Cloud</h2><p style="margin:0 0 14px;color:#5d6874;font-size:13px">حساب موحد بين Android وWindows</p><div id="hseCloudPanelBody"></div><div id="hseCloudPanelMsg" role="status" style="min-height:22px;margin-top:10px;font-size:12px"></div><button id="hseCloudClose" style="width:100%;padding:10px;border:0;border-radius:9px;margin-top:8px">إغلاق</button></section>';
      document.body.appendChild(m);
      m.addEventListener('click',e=>{if(e.target===m)m.remove()});
      document.getElementById('hseCloudClose').onclick=()=>m.remove();
    }
    const body=document.getElementById('hseCloudPanelBody');
    const msg=document.getElementById('hseCloudPanelMsg');
    const u=user();
    if(!u) {
      body.innerHTML='<input id="hseCloudEmail" type="email" autocomplete="username" placeholder="البريد الإلكتروني" style="box-sizing:border-box;width:100%;padding:12px;margin:5px 0;border:1px solid #cbd5e1;border-radius:9px"><input id="hseCloudPassword" type="password" autocomplete="current-password" placeholder="كلمة المرور" style="box-sizing:border-box;width:100%;padding:12px;margin:5px 0;border:1px solid #cbd5e1;border-radius:9px"><div style="display:flex;gap:8px;margin-top:10px"><button id="hseCloudLogin" style="flex:1;padding:11px;border:0;border-radius:9px;background:#0b6585;color:#fff">دخول</button><button id="hseCloudBootstrap" style="flex:1;padding:11px;border:0;border-radius:9px">إنشاء المدير الأول</button></div>';
      document.getElementById('hseCloudLogin').onclick=async()=>{try{await login(document.getElementById('hseCloudEmail').value.trim(),document.getElementById('hseCloudPassword').value);location.reload()}catch(e){msg.textContent=e.message;msg.style.color='#b42318'}};
      document.getElementById('hseCloudBootstrap').onclick=async()=>{const code=prompt('رمز التهيئة الأولية الذي يوفره مسؤول النظام');if(!code)return;try{await bootstrap(document.getElementById('hseCloudEmail').value.trim(),document.getElementById('hseCloudPassword').value,prompt('الاسم الظاهر','مسؤول HSE')||'مسؤول HSE',code);location.reload()}catch(e){msg.textContent=e.message;msg.style.color='#b42318'}};
    } else {
      body.innerHTML='<div style="background:#eff6f8;padding:10px;border-radius:9px;margin-bottom:10px">متصل: <b>'+esc(u.email||u.displayName)+'</b> — '+esc(u.role)+'</div><div style="display:flex;gap:8px;flex-wrap:wrap"><button id="hseCloudPush" style="flex:1;padding:11px;border:0;border-radius:9px;background:#0b6585;color:#fff">مزامنة</button><button id="hseCloudPull" style="flex:1;padding:11px;border:0;border-radius:9px">تنزيل</button><button id="hseCloudLogout" style="flex:1;padding:11px;border:0;border-radius:9px">خروج</button></div>'+(u.role==='admin'?'<hr style="margin:14px 0;border:0;border-top:1px solid #e2e8f0"><h3 style="font-size:15px;margin:0 0 8px">إضافة مستخدم</h3><input id="hseNewName" placeholder="الاسم الكامل" style="box-sizing:border-box;width:100%;padding:10px;margin:4px 0;border:1px solid #cbd5e1;border-radius:8px"><input id="hseNewEmail" type="email" placeholder="البريد الإلكتروني" style="box-sizing:border-box;width:100%;padding:10px;margin:4px 0;border:1px solid #cbd5e1;border-radius:8px"><input id="hseNewPassword" type="password" placeholder="كلمة المرور (12 حرفاً على الأقل)" style="box-sizing:border-box;width:100%;padding:10px;margin:4px 0;border:1px solid #cbd5e1;border-radius:8px"><select id="hseNewRole" style="box-sizing:border-box;width:100%;padding:10px;margin:4px 0;border:1px solid #cbd5e1;border-radius:8px"><option value="supervisor">مشرف HSE</option><option value="manager">مسؤول HSE</option><option value="viewer">قراءة فقط</option><option value="admin">مدير</option></select><button id="hseCloudCreateUser" style="width:100%;padding:11px;margin-top:6px;border:0;border-radius:9px;background:#0f766e;color:#fff">إنشاء الحساب</button>':'');
      document.getElementById('hseCloudPush').onclick=async()=>{try{const r=await push();msg.style.color='#087443';msg.textContent=`رفع ${r.uploaded} • تنزيل ${r.downloaded} • دون تغيير ${r.unchanged} • تعارض ${r.conflicts.length}`;if(r.conflicts.length)msg.textContent+=' — راجع التعارضات: '+r.conflicts.join(', ')}catch(e){msg.style.color='#b42318';msg.textContent=e.message}};
      document.getElementById('hseCloudPull').onclick=async()=>{try{const n=await pull();msg.style.color='#087443';msg.textContent='تم تنزيل '+n+' عنصر'}catch(e){msg.style.color='#b42318';msg.textContent=e.message}};
      document.getElementById('hseCloudLogout').onclick=async()=>{await logout();location.reload()};
      const createButton=document.getElementById('hseCloudCreateUser');
      if(createButton) createButton.onclick=async()=>{
        try {
          await createUser({
            email:document.getElementById('hseNewEmail').value.trim(),
            displayName:document.getElementById('hseNewName').value.trim(),
            password:document.getElementById('hseNewPassword').value,
            role:document.getElementById('hseNewRole').value
          });
          msg.style.color='#087443'; msg.textContent='تم إنشاء الحساب بنجاح.';
          ['hseNewName','hseNewEmail','hseNewPassword'].forEach(id=>document.getElementById(id).value='');
        } catch(e) { msg.style.color='#b42318'; msg.textContent=e.message; }
      };
    }
  }
  function bridgeAppLogin() {
    const emailInput=document.getElementById('v2User');
    const passInput=document.getElementById('v2Pass');
    if(emailInput) { emailInput.type='email'; emailInput.value=''; emailInput.placeholder='البريد الإلكتروني'; emailInput.autocomplete='username'; }
    if(passInput) { passInput.value=''; passInput.autocomplete='current-password'; }
    const labels=document.querySelectorAll('#v2Login label');
    if(labels[0]) labels[0].textContent='البريد الإلكتروني';
    const warning=document.querySelector('#v2Login .v2-danger');
    if(warning) warning.textContent='تسجيل الدخول موحد وآمن عبر Cloudflare. يلزم إنشاء حساب المدير الأول قبل الاستخدام.';
    window.v2Login=async()=>{
      const email=document.getElementById('v2User')?.value.trim();
      const password=document.getElementById('v2Pass')?.value;
      const err=document.getElementById('v2LoginErr');
      if(!email||!password){if(err)err.textContent='أدخل البريد الإلكتروني وكلمة المرور.';return}
      try {
        const u=await login(email,password);
        if(window.v2Audit) window.v2Audit('LOGIN','Connexion Cloud ouverte');
        document.getElementById('v2Login')?.classList.add('v2-hidden');
        if(window.v2SetHeader) window.v2SetHeader();
        if(window.v2Toast) window.v2Toast('تم تسجيل الدخول بنجاح');
      } catch(e) { if(err)err.textContent=e.message||'تعذر تسجيل الدخول'; }
    };
    window.v2Logout=async()=>{try{if(window.v2Audit)window.v2Audit('LOGOUT','Session Cloud fermée');await logout()}finally{location.reload()}};
    window.v2Users=()=>openCloudPanel();
    const localSession=safeParse(localStorage.getItem(LOCAL_USER_KEY),null);
    if(!token()) localStorage.removeItem(LOCAL_USER_KEY);
    // Validate saved token; an expired/revoked server session returns the app to login.
    restore().then(u=>{
      if(u) document.getElementById('v2Login')?.classList.add('v2-hidden');
      else document.getElementById('v2Login')?.classList.remove('v2-hidden');
      if(u && window.v2SetHeader) window.v2SetHeader();
    });
  }
  window.HSE107ECloud={login,bootstrap,logout,restore,push,pull,collect,createUser,openPanel:openCloudPanel,api:API,user};
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',()=>{bridgeAppLogin();addCloudButton()});
  else { bridgeAppLogin(); addCloudButton(); }
})();
