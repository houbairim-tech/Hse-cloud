HSE 107E v2.9.1

- Existing HSE 107E modules preserved: Dashboard, Actions, Production, GEMBA, Contact Sécurité, Autorisations, EPC, Compte Rendu, custom tabs, presence, settings, timers and local image storage.
- Android and Windows share the same Cloudflare Worker/D1 authentication.
- Login uses individual email accounts; no default admin/admin123 credentials remain.
- Roles: admin, manager, supervisor, viewer.
- Cloud sync includes version checks and reports conflicting edits instead of silently overwriting them.
- Local data remains available for offline work; sign in and synchronize when connected.
- JSON backup/restore and CSV export remain available.
- PTW, Consignation/LOTO, TBT registers and audit trail remain included.
- Windows renderer can access only the HSE107E Cloudflare API; unrelated external traffic is blocked.

First administrator:
Open the Cloud button and choose “Créer le premier administrateur”. Enter the BOOTSTRAP_CODE secret configured for the hse107e-api Worker. Passwords must contain at least 12 characters.

Build outputs:
- Android: android-app/android/app/build/outputs/apk/debug/app-debug.apk
- Windows installer and portable EXE: desktop/dist/

Important:
A first online login is required to establish the Cloud account. Keep a JSON backup before the first synchronization on each device. Full XLSX import/export requires the local SheetJS file in desktop/libs/.
