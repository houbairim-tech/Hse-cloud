// Google Drive integration (main process only). The renderer never touches the network:
// it calls these functions through the preload bridge (IPC).
const { app, shell, safeStorage } = require('electron');
const fs = require('fs');
const path = require('path');
const http = require('http');
const crypto = require('crypto');

const FOLDER_NAME = 'HSE107E_Sauvegardes';
const DOCS_FOLDER = 'Documents';
const AUTH_URL = 'https://accounts.google.com/o/oauth2/v2/auth';
const TOKEN_URL = 'https://oauth2.googleapis.com/token';
const API = 'https://www.googleapis.com/drive/v3';
const UPLOAD = 'https://www.googleapis.com/upload/drive/v3';

const cfgFile = () => path.join(app.getPath('userData'), 'drive-config.json');
const tokFile = () => path.join(app.getPath('userData'), 'drive-token.bin');

let cfgCache = null, tokCache = null, access = { token: '', exp: 0 }, folderCache = {};

function readCfg() {
  if (cfgCache) return cfgCache;
  try { cfgCache = JSON.parse(fs.readFileSync(cfgFile(), 'utf8')); } catch (e) { cfgCache = {}; }
  return cfgCache;
}
function writeCfg(c) { cfgCache = c; fs.writeFileSync(cfgFile(), JSON.stringify(c)); }

function readTok() {
  if (tokCache) return tokCache;
  try {
    const raw = fs.readFileSync(tokFile());
    const txt = safeStorage.isEncryptionAvailable() ? safeStorage.decryptString(raw) : raw.toString('utf8');
    tokCache = JSON.parse(txt);
  } catch (e) { tokCache = null; }
  return tokCache;
}
function writeTok(t) {
  tokCache = t;
  const txt = JSON.stringify(t);
  fs.writeFileSync(tokFile(), safeStorage.isEncryptionAvailable() ? safeStorage.encryptString(txt) : Buffer.from(txt, 'utf8'));
}
function clearTok() { tokCache = null; access = { token: '', exp: 0 }; folderCache = {}; try { fs.unlinkSync(tokFile()); } catch (e) {} }

function b64url(buf) { return buf.toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, ''); }

async function post(url, params) {
  const r = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams(params).toString() });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(j.error_description || j.error || ('HTTP ' + r.status));
  return j;
}

function scopeOf(cfg) { return cfg.scope === 'drive' ? 'https://www.googleapis.com/auth/drive' : 'https://www.googleapis.com/auth/drive.file'; }

async function accessToken() {
  if (access.token && Date.now() < access.exp - 30000) return access.token;
  const t = readTok(), c = readCfg();
  if (!t || !t.refresh_token) throw new Error('NOT_CONNECTED');
  const j = await post(TOKEN_URL, { client_id: c.clientId, client_secret: c.clientSecret || '', refresh_token: t.refresh_token, grant_type: 'refresh_token' });
  access = { token: j.access_token, exp: Date.now() + (j.expires_in || 3600) * 1000 };
  return access.token;
}

async function api(method, url, opts = {}) {
  const tok = await accessToken();
  const headers = Object.assign({ Authorization: 'Bearer ' + tok }, opts.headers || {});
  const r = await fetch(url, { method, headers, body: opts.body });
  if (opts.raw) { if (!r.ok) throw new Error('HTTP ' + r.status); return r; }
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error((j.error && (j.error.message || j.error)) || ('HTTP ' + r.status));
  return j;
}

const q = s => String(s).replace(/\\/g, '\\\\').replace(/'/g, "\\'");

async function findOrCreateFolder(name, parent) {
  const key = name + '|' + (parent || '');
  if (folderCache[key]) return folderCache[key];
  let query = `name='${q(name)}' and mimeType='application/vnd.google-apps.folder' and trashed=false`;
  if (parent) query += ` and '${parent}' in parents`;
  const l = await api('GET', `${API}/files?q=${encodeURIComponent(query)}&fields=files(id,name,ownedByMe)&orderBy=createdTime&pageSize=20&supportsAllDrives=false`);
  let f = (l.files || []).find(x => x.ownedByMe) || (l.files || [])[0];
  if (!f) {
    f = await api('POST', `${API}/files?fields=id,name`, { headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name, mimeType: 'application/vnd.google-apps.folder', parents: parent ? [parent] : undefined }) });
  }
  folderCache[key] = f.id;
  return f.id;
}

async function multipart(method, url, meta, mime, buf) {
  const boundary = 'hse' + crypto.randomBytes(8).toString('hex');
  const head = Buffer.from(`--${boundary}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n${JSON.stringify(meta)}\r\n--${boundary}\r\nContent-Type: ${mime}\r\n\r\n`);
  const tail = Buffer.from(`\r\n--${boundary}--`);
  return api(method, url, { headers: { 'Content-Type': 'multipart/related; boundary=' + boundary }, body: Buffer.concat([head, buf, tail]) });
}

async function findInFolder(name, folderId) {
  const query = `name='${q(name)}' and '${folderId}' in parents and trashed=false`;
  const l = await api('GET', `${API}/files?q=${encodeURIComponent(query)}&fields=files(id,name)&pageSize=5`);
  return (l.files || [])[0] || null;
}

async function upsert(name, folderId, mime, buf) {
  const ex = await findInFolder(name, folderId);
  if (ex) return multipart('PATCH', `${UPLOAD}/files/${ex.id}?uploadType=multipart&fields=id,name,modifiedTime`, { name }, mime, buf);
  return multipart('POST', `${UPLOAD}/files?uploadType=multipart&fields=id,name,modifiedTime`, { name, parents: [folderId] }, mime, buf);
}

const isOffline = e => /fetch failed|ENOTFOUND|ECONNREFUSED|ETIMEDOUT|ENETUNREACH|network|EAI_AGAIN|ECONNRESET/i.test(String(e && (e.message + ' ' + (e.cause && e.cause.code)) || ''));
const wrap = fn => async (...a) => {
  try { return Object.assign({ ok: true }, await fn(...a)); }
  catch (e) { return { ok: false, offline: isOffline(e), notConnected: e.message === 'NOT_CONNECTED', error: String(e.message || e) }; }
};

async function connect() {
  const c = readCfg();
  if (!c.clientId) throw new Error('Renseignez d’abord le Client ID Google.');
  const verifier = b64url(crypto.randomBytes(48));
  const challenge = b64url(crypto.createHash('sha256').update(verifier).digest());
  const state = b64url(crypto.randomBytes(16));
  const code = await new Promise((resolve, reject) => {
    const srv = http.createServer((req, res) => {
      const u = new URL(req.url, 'http://127.0.0.1');
      if (u.pathname !== '/') { res.writeHead(404); res.end(); return; }
      const err = u.searchParams.get('error'), cd = u.searchParams.get('code');
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
      res.end('<html><body style="font-family:sans-serif;text-align:center;padding:60px"><h2>' + (cd && !err ? '✅ HSE 107E connecté à Google Drive' : '❌ Connexion refusée') + '</h2><p>Vous pouvez fermer cet onglet et revenir à l’application.</p></body></html>');
      clearTimeout(to); srv.close();
      if (err || !cd || u.searchParams.get('state') !== state) reject(new Error(err || 'Réponse invalide')); else resolve({ code: cd, port: srv.address().port });
    });
    const to = setTimeout(() => { srv.close(); reject(new Error('Délai dépassé (3 min).')); }, 180000);
    srv.listen(0, '127.0.0.1', () => {
      const port = srv.address().port;
      const url = AUTH_URL + '?' + new URLSearchParams({ client_id: c.clientId, redirect_uri: `http://127.0.0.1:${port}`, response_type: 'code', scope: scopeOf(c), code_challenge: challenge, code_challenge_method: 'S256', state, access_type: 'offline', prompt: 'consent' }).toString();
      shell.openExternal(url);
    });
  });
  const j = await post(TOKEN_URL, { client_id: c.clientId, client_secret: c.clientSecret || '', code: code.code, code_verifier: verifier, grant_type: 'authorization_code', redirect_uri: `http://127.0.0.1:${code.port}` });
  if (!j.refresh_token) throw new Error('Google n’a pas fourni de jeton de rafraîchissement. Réessayez.');
  access = { token: j.access_token, exp: Date.now() + (j.expires_in || 3600) * 1000 };
  const who = await api('GET', `${API}/about?fields=user(emailAddress,displayName)`);
  writeTok({ refresh_token: j.refresh_token, email: who.user && who.user.emailAddress, scope: scopeOf(c) });
  folderCache = {};
  return { email: who.user && who.user.emailAddress };
}

const handlers = {
  'drive:getConfig': async () => { const c = readCfg(), t = readTok(); return { ok: true, clientId: c.clientId || '', hasSecret: !!c.clientSecret, scope: c.scope || 'drive.file', connected: !!(t && t.refresh_token), email: t && t.email || '' }; },
  'drive:setConfig': async (_e, cfg) => { const c = Object.assign({}, readCfg()); if (typeof cfg.clientId === 'string') c.clientId = cfg.clientId.trim(); if (typeof cfg.clientSecret === 'string' && cfg.clientSecret.trim()) c.clientSecret = cfg.clientSecret.trim(); if (cfg.scope) c.scope = cfg.scope === 'drive' ? 'drive' : 'drive.file'; const prev = readCfg(); if (prev.scope !== c.scope || prev.clientId !== c.clientId) clearTok(); writeCfg(c); return { ok: true }; },
  'drive:connect': wrap(connect),
  'drive:disconnect': async () => { clearTok(); return { ok: true }; },
  // payload: { json: string, name: string, daily: bool }
  'drive:uploadBackup': wrap(async (_e, p) => {
    const folder = await findOrCreateFolder(FOLDER_NAME);
    const buf = Buffer.from(p.json, 'utf8');
    const latest = await upsert('HSE107E_latest.json', folder, 'application/json', buf);
    let daily = null;
    if (p.daily) daily = await upsert(`HSE107E_${new Date().toISOString().slice(0, 10)}.json`, folder, 'application/json', buf);
    return { id: latest.id, modifiedTime: latest.modifiedTime, bytes: buf.length, dailyId: daily && daily.id };
  }),
  // payload: { id, name, mime, b64 }
  'drive:uploadDoc': wrap(async (_e, p) => {
    const root = await findOrCreateFolder(FOLDER_NAME), docs = await findOrCreateFolder(DOCS_FOLDER, root);
    const r = await upsert(`${p.id}__${p.name}`, docs, p.mime || 'application/octet-stream', Buffer.from(p.b64, 'base64'));
    return { id: r.id };
  }),
  'drive:downloadFile': wrap(async (_e, id) => {
    const r = await api('GET', `${API}/files/${encodeURIComponent(id)}?alt=media`, { raw: true });
    return { b64: Buffer.from(await r.arrayBuffer()).toString('base64') };
  }),
  'drive:list': wrap(async () => {
    const folder = await findOrCreateFolder(FOLDER_NAME);
    const l = await api('GET', `${API}/files?q=${encodeURIComponent(`'${folder}' in parents and trashed=false and mimeType='application/json'`)}&fields=files(id,name,modifiedTime,size,ownedByMe,owners(emailAddress))&orderBy=modifiedTime desc&pageSize=60`);
    return { files: l.files || [], folderId: folder };
  }),
  'drive:share': wrap(async (_e, p) => {
    const folder = await findOrCreateFolder(FOLDER_NAME);
    await api('POST', `${API}/files/${folder}/permissions?sendNotificationEmail=true&fields=id`, { headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ type: 'user', role: p.role === 'reader' ? 'reader' : 'writer', emailAddress: String(p.email).trim() }) });
    const f = await api('GET', `${API}/files/${folder}?fields=webViewLink`);
    return { link: f.webViewLink };
  }),
  'drive:openFolder': wrap(async () => {
    const folder = await findOrCreateFolder(FOLDER_NAME);
    const f = await api('GET', `${API}/files/${folder}?fields=webViewLink`);
    if (f.webViewLink) shell.openExternal(f.webViewLink);
    return {};
  })
};

module.exports = handlers;
