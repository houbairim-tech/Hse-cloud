# HSE 107E Desktop v2.9.1
Application Electron pour Windows.

- `npm install`
- `npm run dist`

Les sorties NSIS et portable sont créées dans `dist/`.
Le client Cloudflare est inclus et seul le Worker HSE107E est autorisé depuis le renderer.
Le premier administrateur doit être créé via le bouton Cloud avec le code de bootstrap.
