const { contextBridge, ipcRenderer } = require('electron');
const call = ch => (...a) => ipcRenderer.invoke(ch, ...a);
contextBridge.exposeInMainWorld('hseDrive', {
  available: true,
  getConfig: call('drive:getConfig'),
  setConfig: call('drive:setConfig'),
  connect: call('drive:connect'),
  disconnect: call('drive:disconnect'),
  uploadBackup: call('drive:uploadBackup'),
  uploadDoc: call('drive:uploadDoc'),
  downloadFile: call('drive:downloadFile'),
  list: call('drive:list'),
  share: call('drive:share'),
  openFolder: call('drive:openFolder')
});
