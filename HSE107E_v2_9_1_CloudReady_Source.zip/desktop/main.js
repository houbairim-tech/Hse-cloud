const { app, BrowserWindow, session, ipcMain } = require('electron');
const path = require('path');
const driveHandlers = require('./drive');
Object.entries(driveHandlers).forEach(([ch, fn]) => ipcMain.handle(ch, fn));

// Portable builds keep their profile and local data beside the EXE.
// Installed builds use Electron's normal per-Windows-user AppData directory.
if (process.env.PORTABLE_EXECUTABLE_DIR) {
  app.setPath('userData', path.join(process.env.PORTABLE_EXECUTABLE_DIR, 'HSE107E-Portable-Data'));
}
app.setAppUserModelId('com.hse107e.desktop');

function createWindow() {
  const win = new BrowserWindow({
    width: 1440,
    height: 900,
    minWidth: 1000,
    minHeight: 700,
    autoHideMenuBar: true,
    show: false,
    icon: path.join(__dirname, 'icon.ico'),
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      webSecurity: true,
      allowRunningInsecureContent: false
    }
  });

  // Allow only the authenticated HSE107E Cloudflare API from the renderer.
  // All other external HTTP(S)/WebSocket traffic remains blocked.
  const CLOUD_HOST = 'hse107e-api.hse107e-cloud-api.workers.dev';
  session.defaultSession.webRequest.onBeforeRequest(
    { urls: ['http://*/*', 'https://*/*', 'ws://*/*', 'wss://*/*'] },
    (details, callback) => {
      let allowed = false;
      try {
        const u = new URL(details.url);
        allowed = u.protocol === 'https:' && u.hostname === CLOUD_HOST;
      } catch (_) {}
      callback({ cancel: !allowed });
    }
  );

  win.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  win.webContents.on('will-navigate', (event, url) => {
    if (!url.startsWith('file://')) event.preventDefault();
  });

  win.once('ready-to-show', () => win.show());
  win.loadFile(path.join(__dirname, 'index.html'));
}

app.whenReady().then(() => {
  createWindow();
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
