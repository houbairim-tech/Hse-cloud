// Copie l'application (dossier ../desktop) vers www/ pour Capacitor
const fs = require('fs'), path = require('path');
const src = path.join(__dirname, '..', 'desktop'), dst = path.join(__dirname, 'www');
fs.rmSync(dst, { recursive: true, force: true });
fs.mkdirSync(dst, { recursive: true });
['index.html', 'logo.png', 'icon.png', 'manifest.webmanifest', 'cloud-sync.js'].forEach(f => fs.copyFileSync(path.join(src, f), path.join(dst, f)));
['epc', 'libs'].forEach(d => fs.cpSync(path.join(src, d), path.join(dst, d), { recursive: true }));
console.log('www/ prêt');
