@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo === HSE 107E - Build APK Android ===
echo Prerequis: Node.js LTS, JDK 17, Android Studio (SDK) - variable ANDROID_HOME definie.
call npm install || goto :err
call node prepare-www.js || goto :err
if not exist android ( call npx cap add android || goto :err )
call node apply-icon.js
call npx cap sync android || goto :err
cd android
call gradlew.bat assembleDebug || goto :err
echo.
echo SUCCES: android-app\android\app\build\outputs\apk\debug\app-debug.apk
pause & exit /b 0
:err
echo ERREUR - voir les messages ci-dessus.
pause & exit /b 1
