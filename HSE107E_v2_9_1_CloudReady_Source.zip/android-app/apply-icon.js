// Remplace l'icône Android par défaut par l'icône HSE 107E (à lancer après "npx cap add android")
const fs = require('fs'), path = require('path');
const res = path.join(__dirname, 'android', 'app', 'src', 'main', 'res');
for (const d of fs.readdirSync(path.join(__dirname, 'icons'))) {
  const src = path.join(__dirname, 'icons', d);
  if (!fs.statSync(src).isDirectory()) continue;
  fs.mkdirSync(path.join(res, d), { recursive: true });
  for (const f of fs.readdirSync(src)) fs.copyFileSync(path.join(src, f), path.join(res, d, f));
}
// supprime les icônes adaptatives par défaut pour utiliser nos PNG
fs.rmSync(path.join(res, 'mipmap-anydpi-v26'), { recursive: true, force: true });
for (const d of fs.readdirSync(res)) if (d.startsWith('mipmap-')) for (const f of fs.readdirSync(path.join(res, d))) if (f.startsWith('ic_launcher_foreground') ) fs.rmSync(path.join(res, d, f), { force: true });
console.log('Icône HSE 107E appliquée');
